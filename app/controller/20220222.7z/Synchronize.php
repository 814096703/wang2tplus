<?php
namespace app\controller;

use app\BaseController;
use think\facade\Db;

include_once(__DIR__."/../api/wdtsdk.php");
include_once(__DIR__."/Wang.php");
include_once(__DIR__."/../api/MyTplusSdk.php");
include_once(__DIR__."/TplusApi.php");
include_once(__DIR__."/TplusApi2.php");

class Synchronize extends BaseController
{
    public function index()
    {
        return '<style type="text/css">*{ padding: 0; margin: 0; } div{ padding: 4px 48px;} a{color:#2E5CD5;cursor: pointer;text-decoration: none} a:hover{text-decoration:underline; } body{ background: #fff; font-family: "Century Gothic","Microsoft yahei"; color: #333;font-size:18px;} h1{ font-size: 100px; font-weight: normal; margin-bottom: 12px; } p{ line-height: 1.6em; font-size: 42px }</style><div style="padding: 24px 48px;"> <h1>:) </h1><p> ThinkPHP V' . \think\facade\App::version() . '<br/><span style="font-size:30px;">14载初心不改 - 你值得信赖的PHP框架</span></p><span style="font-size:25px;">[ V6.0 版本由 <a href="https://www.yisu.com/" target="yisu">亿速云</a> 独家赞助发布 ]</span></div><script type="text/javascript" src="https://tajs.qq.com/stats?sId=64890268" charset="UTF-8"></script><script type="text/javascript" src="https://e.topthink.com/Public/static/client.js"></script><think id="ee9b1aa918103c4fc"></think>';
    }

    public function hello($name = 'ThinkPHP6')
    {
        return 'hello,' . $name;
    }

    public function test(){
        

    }

    public function start(){
        $startTime = '2022-02-01';
        $endTime = '2022-02-21';

        $diff= strtotime($endTime) - strtotime($startTime) ;

        $days =abs(round($diff / 86400));

        echo "相差: ".$days."天";
        // $dateArr = getRangeTimeArrDays($days+1);
        // $warehouseArr = ['xishuicun3-test', '8013'];
        // foreach($warehouseArr as $warehouse){
            
        // }
    }

    public function synchronizeVoucher(){
        
    }

    

}

// 销售出库单
function synchronizeStockOut($days){
    $rangeTimeArr = getRangeTimeArrHours($days);
    foreach($rangeTimeArr as $index=>$rangeTime){
        
        $wangData = qmTest($rangeTime['start'], $rangeTime['end']);
        if($wangData->status==0){
            $orders = $wangData->data->order;
            $total = $wangData->data->total_count;
            if($total>0){
                foreach($orders as $order){
                   
                    // 查询单据是否已转到t+
                    $row = Db::table('voucher_log')->where('voucher_id',$order->order_no)->find();
                    // dump($row);
                    
                    if(!$row){
                        dump($order);
                        // 单据录入到t+
                        $res = w2tStockOut($order);
                        dump($res);
                        if($res=='null'){
                            // 单据信息录入到数据库
                            $newRow = ['voucher_id'=>$order->order_no, 'isSuccess'=>1, 'voucher_type'=>'销售出库单'];
                            $rownum = Db::table('voucher_log')->insert($newRow);
                            dump($rownum);
                        }
                        
                    }
                }
            }
        }
    }
}

function w2tStockOut($w_order){
    $details = '';
    foreach($w_order->details_list as $key=>$item){

        $price = (floatval($item->cost_price)>=0.01 ? floatval($item->cost_price) : 0);
        $amount =( floatval($item->total_amount)>=0.01 ? floatval($item->total_amount) : 0);
        // dump($item);
        
        $detail = '{
            Inventory: {
                Code: "'.$item->goods_no.'"
            },
            BaseQuantity: '.$item->goods_count.',
            Price: '.$price.',
            Amount: '.$amount.',
            origTaxSalePrice: '.$item->sell_price.',
            IsPresent: '.($item->gift_type?'true':'false').',
            DynamicPropertyKeys: ["pubuserdefnvc1", "pubuserdefnvc2", "pubuserdefnvc3"],
            DynamicPropertyValues: ["'.$w_order->src_trade_no.'", "'.$w_order->src_order_no.'", "'.$w_order->order_no.'"]
        }';
        if(count($w_order->details_list)==($key+1)){
            $details.=$detail;
        }else{
            $details.=$detail.',';
        }
    }
    
    // 转化为t+数据格式
    $content = '{
        dto: {
            IsModifiedCode:"true",
            Code: "'.$w_order->order_no.'",
            VoucherType: {
                Code: "ST1021"
            },
            Partner: {
                Code: "'.$w_order->shop_no.'"
            },
            VoucherDate: "'.date('Y-m-d',strtotime($w_order->consign_time)).'",
            BusiType: {
                Code: "15"
            },
            Warehouse: {
                Code: "'.$w_order->warehouse_no.'"
            },
            Clerk: {
                Code: "'.$w_order->salesman_no.'"
            },
            Memo: "'.$w_order->remark.'",
            RDRecordDetails: [
                '.$details.'
            ]
        }
    }';

    if($w_order->warehouse_no=='8013'){
        $res = saleDispatchCreate(env('TPLUS2.appKey'), env('TPLUS2.appSecret'), TplusApi2::getOpenToken(), $content);
    }else{
        $res = saleDispatchCreate(env('TPLUS.appKey'), env('TPLUS.appSecret'), getOpenToken(), $content);
    }
    // $res = saleDispatchCreate(env('TPLUS.appKey'), env('TPLUS.appSecret'), getOpenToken(), $content);
    // dump($res);
    return $res;
}

// 销售出库单
function stockOut($days){
    $rangeTimeArr = getRangeTimeArrHours($days);
    foreach($rangeTimeArr as $index=>$rangeTime){
        // 查询旺店通单据
        if($index%24==0){
            usleep(100*1000);
        }
        $wangData = qmTest($rangeTime['start'], $rangeTime['end']);
        // sleep(1); if($i==10) sleep(1);
        if($wangData->status==0){
            $orders = $wangData->data->order;
            $total = $wangData->data->total_count;
            if($total>0){
                foreach($orders as $order){
                    
                    // 查询单据是否已转到t+
                    $row = Db::table('voucher_log')->where('voucher_id',$order->order_no)->find();
                    // dump($row);
                    
                    if(!$row){
                        dump($order);
                        // 单据录入到t+
                        $res = w2tStockOut($order);
                        dump($res);
                        if($res=='null'){
                            // 单据信息录入到数据库
                            $newRow = ['voucher_id'=>$order->order_no, 'isSuccess'=>1, 'voucher_type'=>'销售出库单'];
                            $rownum = Db::table('voucher_log')->insert($newRow);
                            dump($rownum);
                        }
                        
                    }
                }
            }
        }
    }
}

function w2tStockOut($w_order){
    $details = '';
    foreach($w_order->details_list as $key=>$item){

        $price = (floatval($item->cost_price)>=0.01 ? floatval($item->cost_price) : 0);
        $amount =( floatval($item->total_amount)>=0.01 ? floatval($item->total_amount) : 0);
        // dump($item);
        
        $detail = '{
            Inventory: {
                Code: "'.$item->goods_no.'"
            },
            BaseQuantity: '.$item->goods_count.',
            Price: '.$price.',
            Amount: '.$amount.',
            origTaxSalePrice: '.$item->sell_price.',
            IsPresent: '.($item->gift_type?'true':'false').',
            DynamicPropertyKeys: ["pubuserdefnvc1", "pubuserdefnvc2", "pubuserdefnvc3"],
            DynamicPropertyValues: ["'.$w_order->src_trade_no.'", "'.$w_order->src_order_no.'", "'.$w_order->order_no.'"]
        }';
        if(count($w_order->details_list)==($key+1)){
            $details.=$detail;
        }else{
            $details.=$detail.',';
        }
    }
    
    // 转化为t+数据格式
    $content = '{
        dto: {
            IsModifiedCode:"true",
            Code: "'.$w_order->order_no.'",
            VoucherType: {
                Code: "ST1021"
            },
            Partner: {
                Code: "'.$w_order->shop_no.'"
            },
            VoucherDate: "'.date('Y-m-d',strtotime($w_order->consign_time)).'",
            BusiType: {
                Code: "15"
            },
            Warehouse: {
                Code: "'.$w_order->warehouse_no.'"
            },
            Clerk: {
                Code: "'.$w_order->salesman_no.'"
            },
            Memo: "'.$w_order->remark.'",
            RDRecordDetails: [
                '.$details.'
            ]
        }
    }';

    if($w_order->warehouse_no=='8013'){
        $res = saleDispatchCreate(env('TPLUS2.appKey'), env('TPLUS2.appSecret'), TplusApi2::getOpenToken(), $content);
    }else{
        $res = saleDispatchCreate(env('TPLUS.appKey'), env('TPLUS.appSecret'), getOpenToken(), $content);
    }
    // $res = saleDispatchCreate(env('TPLUS.appKey'), env('TPLUS.appSecret'), getOpenToken(), $content);
    // dump($res);
    return $res;
}

// 获取日期间隔，间隔一天
function getRangeTimeArrDays($days){
    $rangeTimeArr = array();
    $startTime = date("Y-m-d").' 23:59:59';
    for($i=0;$i<$days;$i++){
        $et = $startTime;
        $startTime = date('Y-m-d H:i:s',strtotime("$startTime - 1 days"));
        $st = $startTime;
        array_push($rangeTimeArr, array('start'=>$st, 'end'=>$et));
    }
    dump($rangeTimeArr);
    return $rangeTimeArr;
}

// 获取日期间隔，间隔一小时
function getRangeTimeArrHours($days){
    $rangeTimeArr = array();
    $now = date('Y-m-d H:i:s');
    $startTime = date("Y-m-d").' 23:59:59';
    for($i=0;$i<$days;$i++){
        for($j=0;$j<24;$j++){
            $et = $startTime;
            $startTime = date('Y-m-d H:i:s',strtotime("$startTime - 1 hours"));
            $st = $startTime;
            if(strtotime($et)>strtotime($now) && strtotime($st)<strtotime($now)){
                $et = date('Y-m-d H:i:s',strtotime("$now - 1 minutes"));
            }
            if(strtotime($st)>strtotime($now)){
                continue;
            }
            array_push($rangeTimeArr, array('start'=>$st, 'end'=>$et));
        }
    }
    // dump($rangeTimeArr);
    return $rangeTimeArr;
}
